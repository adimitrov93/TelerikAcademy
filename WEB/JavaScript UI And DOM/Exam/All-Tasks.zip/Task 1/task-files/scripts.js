function createImagesPreviewer(selector, items) {

}