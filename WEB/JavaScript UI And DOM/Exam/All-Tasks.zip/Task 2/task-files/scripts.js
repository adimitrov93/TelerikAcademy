$.fn.gallery = function () {
    
};